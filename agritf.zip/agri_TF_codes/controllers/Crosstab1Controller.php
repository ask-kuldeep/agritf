<?php

namespace PHPMaker2024\project6;

use Psr\Http\Message\ServerRequestInterface as Request;
use Psr\Http\Message\ResponseInterface as Response;
use PHPMaker2024\project6\Attributes\Delete;
use PHPMaker2024\project6\Attributes\Get;
use PHPMaker2024\project6\Attributes\Map;
use PHPMaker2024\project6\Attributes\Options;
use PHPMaker2024\project6\Attributes\Patch;
use PHPMaker2024\project6\Attributes\Post;
use PHPMaker2024\project6\Attributes\Put;

/**
 * Crosstab1 controller
 */
class Crosstab1Controller extends ControllerBase
{
    // crosstab
    #[Map(["GET", "POST", "OPTIONS"], "/Crosstab1", [PermissionMiddleware::class], "crosstab.Crosstab1")]
    public function crosstab(Request $request, Response $response, array $args): Response
    {
        return $this->runPage($request, $response, $args, "Crosstab1Crosstab");
    }
}
