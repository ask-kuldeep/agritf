Subject: Password Changed
From: <?= $From ?>
To: <?= $To ?>
Cc:
Bcc:
Format: HTML

<p>Dear Sir/Madam,</p>

<p>Your password has been changed.</p>

<p>Please feel free to contact us in case of further queries.</p>

<p>
Best Regards,<br>
Support
</p>