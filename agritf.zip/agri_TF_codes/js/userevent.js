ew.events={};ew.charts={};ew.clientScript=function(){};ew.startupScript=function(){};
