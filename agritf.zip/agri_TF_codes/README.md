FastRoute - Fast request router for PHP
=======================================

This code provides a comprehensive framework for the agriculture enhancement using emerging technologies

Install
-------

read the readme.md file in each component to run the framework correctly.

all the artificial intelligence models are available in the models package.
