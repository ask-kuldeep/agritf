<?php return \Symfony\Component\VarExporter\Internal\Hydrator::hydrate(
    $o = [
        clone (($p = &\Symfony\Component\VarExporter\Internal\Registry::$prototypes)['PHPMaker2024\\project6\\Attributes\\Map'] ?? \Symfony\Component\VarExporter\Internal\Registry::p('PHPMaker2024\\project6\\Attributes\\Map')),
        clone $p['PHPMaker2024\\project6\\Attributes\\Map'],
        clone $p['PHPMaker2024\\project6\\Attributes\\Map'],
        clone $p['PHPMaker2024\\project6\\Attributes\\Map'],
        clone $p['PHPMaker2024\\project6\\Attributes\\Map'],
        clone ($p['PHPMaker2024\\project6\\Attributes\\Get'] ?? \Symfony\Component\VarExporter\Internal\Registry::p('PHPMaker2024\\project6\\Attributes\\Get')),
        clone $p['PHPMaker2024\\project6\\Attributes\\Get'],
        clone $p['PHPMaker2024\\project6\\Attributes\\Map'],
        clone $p['PHPMaker2024\\project6\\Attributes\\Map'],
        clone $p['PHPMaker2024\\project6\\Attributes\\Map'],
        clone $p['PHPMaker2024\\project6\\Attributes\\Map'],
    ],
    null,
    [
        'PHPMaker2024\\project6\\Attributes\\Map' => [
            'methods' => [
                [
                    'GET',
                    'POST',
                    'OPTIONS',
                ],
                [
                    'GET',
                    'POST',
                    'OPTIONS',
                ],
                [
                    'GET',
                    'POST',
                    'OPTIONS',
                ],
                [
                    'GET',
                    'POST',
                    'OPTIONS',
                ],
                [
                    'GET',
                    'POST',
                    'OPTIONS',
                ],
                [
                    'GET',
                ],
                [
                    'GET',
                ],
                [
                    'GET',
                    'POST',
                    'OPTIONS',
                ],
                [
                    'GET',
                    'POST',
                    'OPTIONS',
                ],
                [
                    'GET',
                    'POST',
                    'OPTIONS',
                ],
                [
                    'GET',
                    'POST',
                    'OPTIONS',
                ],
            ],
            'pattern' => [
                '/Crosstab1',
                '/MomtransList',
                '/MomtransAdd',
                '/login[/{provider}]',
                '/logout',
                '/swagger/swagger',
                '/[index]',
                '/UsersList',
                '/UsersAdd',
                '/View1List',
                '/View2List',
            ],
            'handler' => [
                'PHPMaker2024\\project6\\Crosstab1Controller:crosstab',
                'PHPMaker2024\\project6\\MomtransController:list',
                'PHPMaker2024\\project6\\MomtransController:add',
                'PHPMaker2024\\project6\\OthersController:login',
                'PHPMaker2024\\project6\\OthersController:logout',
                'PHPMaker2024\\project6\\OthersController:swagger',
                'PHPMaker2024\\project6\\OthersController:index',
                'PHPMaker2024\\project6\\UsersController:list',
                'PHPMaker2024\\project6\\UsersController:add',
                'PHPMaker2024\\project6\\View1Controller:list',
                'PHPMaker2024\\project6\\View2Controller:list',
            ],
            'middleware' => [
                [
                    'PHPMaker2024\\project6\\PermissionMiddleware',
                ],
                [
                    'PHPMaker2024\\project6\\PermissionMiddleware',
                ],
                [
                    'PHPMaker2024\\project6\\PermissionMiddleware',
                ],
                [
                    'PHPMaker2024\\project6\\PermissionMiddleware',
                ],
                [
                    'PHPMaker2024\\project6\\PermissionMiddleware',
                ],
                [],
                [
                    'PHPMaker2024\\project6\\PermissionMiddleware',
                ],
                [
                    'PHPMaker2024\\project6\\PermissionMiddleware',
                ],
                [
                    'PHPMaker2024\\project6\\PermissionMiddleware',
                ],
                [
                    'PHPMaker2024\\project6\\PermissionMiddleware',
                ],
                [
                    'PHPMaker2024\\project6\\PermissionMiddleware',
                ],
            ],
            'name' => [
                'crosstab.Crosstab1',
                'list.momtrans',
                'add.momtrans',
                'login',
                'logout',
                'swagger',
                'index',
                'list.users',
                'add.users',
                'list.view1',
                'list.view2',
            ],
            'options' => [
                [],
                [],
                [],
                [],
                [],
                [],
                [],
                [],
                [],
                [],
                [],
            ],
        ],
    ],
    [
        $o[0],
        $o[1],
        $o[2],
        $o[3],
        $o[4],
        $o[5],
        $o[6],
        $o[7],
        $o[8],
        $o[9],
        $o[10],
    ],
    []
);