function getmoisture($moisture,$iotname, $token = false)
{
//$servername = "localhost";
//$username = "root";
//$password = "admin";
//$dbname = "agri";

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);
// Check connection
if ($conn->connect_error) {
  die("Connection failed: " . $conn->connect_error);
}

$sql = "INSERT INTO moisturetrans (moisture, iotcomponent)
VALUES ('$moisture', '$iotname')";

if ($conn->query($sql) === TRUE) {
  echo "New record created successfully";
} else {
  echo "Error: " . $sql . "<br>" . $conn->error;
}

$conn->close();
}

/*
{
   "dt":2023.11.10,
   "t10":281.96,
   "moisture":0.175,
   "t0":279.02
}

*/