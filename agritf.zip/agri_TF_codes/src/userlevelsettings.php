<?php
/**
 * PHPMaker 2024 User Level Settings
 */
namespace PHPMaker2024\project6;

/**
 * User levels
 *
 * @var array<int, string>
 * [0] int User level ID
 * [1] string User level name
 */
$USER_LEVELS = [["-2","Anonymous"]];

/**
 * User level permissions
 *
 * @var array<string, int, int>
 * [0] string Project ID + Table name
 * [1] int User level ID
 * [2] int Permissions
 */
$USER_LEVEL_PRIVS = [["{C2894F32-0318-4B28-8206-4A1BAE821044}momtrans","-2","0"],
    ["{C2894F32-0318-4B28-8206-4A1BAE821044}users","-2","0"],
    ["{C2894F32-0318-4B28-8206-4A1BAE821044}view1","-2","0"],
    ["{C2894F32-0318-4B28-8206-4A1BAE821044}view2","-2","0"],
    ["{C2894F32-0318-4B28-8206-4A1BAE821044}Dashboard1","-2","0"],
    ["{C2894F32-0318-4B28-8206-4A1BAE821044}Crosstab1","-2","0"]];

/**
 * Tables
 *
 * @var array<string, string, string, bool, string>
 * [0] string Table name
 * [1] string Table variable name
 * [2] string Table caption
 * [3] bool Allowed for update (for userpriv.php)
 * [4] string Project ID
 * [5] string URL (for OthersController::index)
 */
$USER_LEVEL_TABLES = [["momtrans","momtrans","momtrans",true,"{C2894F32-0318-4B28-8206-4A1BAE821044}","MomtransList"],
    ["users","users","users",true,"{C2894F32-0318-4B28-8206-4A1BAE821044}","UsersList"],
    ["view1","view1","view 1",true,"{C2894F32-0318-4B28-8206-4A1BAE821044}","View1List"],
    ["view2","view2","view 2",true,"{C2894F32-0318-4B28-8206-4A1BAE821044}","View2List"],
    ["Dashboard1","Dashboard1","Dashboard 1",true,"{C2894F32-0318-4B28-8206-4A1BAE821044}",""],
    ["Crosstab1","Crosstab1","Crosstab 1",true,"{C2894F32-0318-4B28-8206-4A1BAE821044}","Crosstab1"]];
