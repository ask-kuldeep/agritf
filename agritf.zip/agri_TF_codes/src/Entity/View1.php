<?php

namespace PHPMaker2024\project6\Entity;

use DateTime;
use DateTimeImmutable;
use DateInterval;
use Doctrine\ORM\Mapping\Column;
use Doctrine\ORM\Mapping\Entity;
use Doctrine\ORM\Mapping\GeneratedValue;
use Doctrine\ORM\Mapping\Id;
use Doctrine\ORM\Mapping\Table;
use Doctrine\ORM\Mapping\SequenceGenerator;
use Doctrine\DBAL\Types\Types;
use PHPMaker2024\project6\AbstractEntity;
use PHPMaker2024\project6\AdvancedSecurity;
use PHPMaker2024\project6\UserProfile;
use function PHPMaker2024\project6\Config;
use function PHPMaker2024\project6\EntityManager;
use function PHPMaker2024\project6\RemoveXss;
use function PHPMaker2024\project6\HtmlDecode;
use function PHPMaker2024\project6\EncryptPassword;

/**
 * Entity class for "view1" table
 */
#[Entity]
#[Table(name: "view1")]
class View1 extends AbstractEntity
{
    public static array $propertyNames = [
        'id' => 'id',
        'department' => 'department',
        'description' => 'description',
        'actiontobetaken' => 'actiontobetaken',
        'Origdate' => 'origdate',
        'responsibility' => 'responsibility',
        'reviewdate' => 'reviewdate',
    ];

    #[Column(type: "integer")]
    private int $id = 0;

    #[Column(type: "text")]
    private string $department;

    #[Column(type: "text")]
    private string $description;

    #[Column(type: "text")]
    private string $actiontobetaken;

    #[Column(name: "Origdate", type: "date")]
    private DateTime $origdate;

    #[Column(type: "text")]
    private string $responsibility;

    #[Column(type: "date")]
    private DateTime $reviewdate;

    public function getId(): int
    {
        return $this->id;
    }

    public function setId(int $value): static
    {
        $this->id = $value;
        return $this;
    }

    public function getDepartment(): string
    {
        return HtmlDecode($this->department);
    }

    public function setDepartment(string $value): static
    {
        $this->department = RemoveXss($value);
        return $this;
    }

    public function getDescription(): string
    {
        return HtmlDecode($this->description);
    }

    public function setDescription(string $value): static
    {
        $this->description = RemoveXss($value);
        return $this;
    }

    public function getActiontobetaken(): string
    {
        return HtmlDecode($this->actiontobetaken);
    }

    public function setActiontobetaken(string $value): static
    {
        $this->actiontobetaken = RemoveXss($value);
        return $this;
    }

    public function getOrigdate(): DateTime
    {
        return $this->origdate;
    }

    public function setOrigdate(DateTime $value): static
    {
        $this->origdate = $value;
        return $this;
    }

    public function getResponsibility(): string
    {
        return HtmlDecode($this->responsibility);
    }

    public function setResponsibility(string $value): static
    {
        $this->responsibility = RemoveXss($value);
        return $this;
    }

    public function getReviewdate(): DateTime
    {
        return $this->reviewdate;
    }

    public function setReviewdate(DateTime $value): static
    {
        $this->reviewdate = $value;
        return $this;
    }
}
