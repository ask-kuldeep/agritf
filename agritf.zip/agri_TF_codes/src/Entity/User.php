<?php

namespace PHPMaker2024\project6\Entity;

use DateTime;
use DateTimeImmutable;
use DateInterval;
use Doctrine\ORM\Mapping\Column;
use Doctrine\ORM\Mapping\Entity;
use Doctrine\ORM\Mapping\GeneratedValue;
use Doctrine\ORM\Mapping\Id;
use Doctrine\ORM\Mapping\Table;
use Doctrine\ORM\Mapping\SequenceGenerator;
use Doctrine\DBAL\Types\Types;
use PHPMaker2024\project6\AbstractEntity;
use PHPMaker2024\project6\AdvancedSecurity;
use PHPMaker2024\project6\UserProfile;
use function PHPMaker2024\project6\Config;
use function PHPMaker2024\project6\EntityManager;
use function PHPMaker2024\project6\RemoveXss;
use function PHPMaker2024\project6\HtmlDecode;
use function PHPMaker2024\project6\EncryptPassword;

/**
 * Entity class for "users" table
 */
#[Entity]
#[Table(name: "users")]
class User extends AbstractEntity
{
    public static array $propertyNames = [
        'id' => 'id',
        'firstname' => 'firstname',
        'middlename' => 'middlename',
        'lastname' => 'lastname',
        'username' => 'username',
        'password' => 'password',
        'avatar' => 'avatar',
        'last_login' => 'lastLogin',
        'type' => 'type',
        'date_added' => 'dateAdded',
        'date_updated' => 'dateUpdated',
    ];

    #[Column(type: "integer")]
    private int $id = 0;

    #[Column(type: "string")]
    private string $firstname;

    #[Column(type: "text", nullable: true)]
    private ?string $middlename;

    #[Column(type: "string")]
    private string $lastname;

    #[Column(type: "text")]
    private string $username;

    #[Column(type: "text")]
    private string $password;

    #[Column(type: "text", nullable: true)]
    private ?string $avatar;

    #[Column(name: "last_login", type: "datetime", nullable: true)]
    private ?DateTime $lastLogin;

    #[Column(type: "boolean")]
    private bool $type = false;

    #[Column(name: "date_added", type: "datetime")]
    private DateTime $dateAdded;

    #[Column(name: "date_updated", type: "datetime", nullable: true)]
    private ?DateTime $dateUpdated;

    public function getId(): int
    {
        return $this->id;
    }

    public function setId(int $value): static
    {
        $this->id = $value;
        return $this;
    }

    public function getFirstname(): string
    {
        return HtmlDecode($this->firstname);
    }

    public function setFirstname(string $value): static
    {
        $this->firstname = RemoveXss($value);
        return $this;
    }

    public function getMiddlename(): ?string
    {
        return HtmlDecode($this->middlename);
    }

    public function setMiddlename(?string $value): static
    {
        $this->middlename = RemoveXss($value);
        return $this;
    }

    public function getLastname(): string
    {
        return HtmlDecode($this->lastname);
    }

    public function setLastname(string $value): static
    {
        $this->lastname = RemoveXss($value);
        return $this;
    }

    public function getUsername(): string
    {
        return HtmlDecode($this->username);
    }

    public function setUsername(string $value): static
    {
        $this->username = RemoveXss($value);
        return $this;
    }

    public function getPassword(): string
    {
        return HtmlDecode($this->password);
    }

    public function setPassword(string $value): static
    {
        $this->password = RemoveXss($value);
        return $this;
    }

    public function getAvatar(): ?string
    {
        return HtmlDecode($this->avatar);
    }

    public function setAvatar(?string $value): static
    {
        $this->avatar = RemoveXss($value);
        return $this;
    }

    public function getLastLogin(): ?DateTime
    {
        return $this->lastLogin;
    }

    public function setLastLogin(?DateTime $value): static
    {
        $this->lastLogin = $value;
        return $this;
    }

    public function getType(): bool
    {
        return $this->type;
    }

    public function setType(bool $value): static
    {
        $this->type = $value;
        return $this;
    }

    public function getDateAdded(): DateTime
    {
        return $this->dateAdded;
    }

    public function setDateAdded(DateTime $value): static
    {
        $this->dateAdded = $value;
        return $this;
    }

    public function getDateUpdated(): ?DateTime
    {
        return $this->dateUpdated;
    }

    public function setDateUpdated(?DateTime $value): static
    {
        $this->dateUpdated = $value;
        return $this;
    }
}
