<?php

namespace PHPMaker2024\project6;

// Navbar menu
$topMenu = new Menu("navbar", true, true);
echo $topMenu->toScript();

// Sidebar menu
$sideMenu = new Menu("menu", true, false);
$sideMenu->addMenuItem(1, "mi_momtrans", $Language->menuPhrase("1", "MenuText"), "MomtransList", -1, "", IsLoggedIn() || AllowListMenu('{C2894F32-0318-4B28-8206-4A1BAE821044}momtrans'), false, false, "", "", false, true);
$sideMenu->addMenuItem(2, "mi_users", $Language->menuPhrase("2", "MenuText"), "UsersList", -1, "", IsLoggedIn() || AllowListMenu('{C2894F32-0318-4B28-8206-4A1BAE821044}users'), false, false, "", "", false, true);
$sideMenu->addMenuItem(3, "mi_view1", $Language->menuPhrase("3", "MenuText"), "View1List", -1, "", IsLoggedIn() || AllowListMenu('{C2894F32-0318-4B28-8206-4A1BAE821044}view1'), false, false, "", "", false, true);
$sideMenu->addMenuItem(4, "mi_view2", $Language->menuPhrase("4", "MenuText"), "View2List", -1, "", IsLoggedIn() || AllowListMenu('{C2894F32-0318-4B28-8206-4A1BAE821044}view2'), false, false, "", "", false, true);
$sideMenu->addMenuItem(6, "mi_Crosstab1", $Language->menuPhrase("6", "MenuText"), "Crosstab1", -1, "", IsLoggedIn() || AllowListMenu('{C2894F32-0318-4B28-8206-4A1BAE821044}Crosstab1'), false, false, "", "", false, true);
$sideMenu->addMenuItem(7, "mci_Miscelleneous", $Language->menuPhrase("7", "MenuText"), "", -1, "", true, false, true, "", "", false, true);
echo $sideMenu->toScript();
