<?php

namespace PHPMaker2024\project6;

// Page object
$MomtransAdd = &$Page;
?>
<script>
var currentTable = <?= JsonEncode($Page->toClientVar()) ?>;
ew.deepAssign(ew.vars, { tables: { momtrans: currentTable } });
var currentPageID = ew.PAGE_ID = "add";
var currentForm;
var fmomtransadd;
loadjs.ready(["wrapper", "head"], function () {
    let $ = jQuery;
    let fields = currentTable.fields;

    // Form object
    let form = new ew.FormBuilder()
        .setId("fmomtransadd")
        .setPageId("add")

        // Add fields
        .setFields([
            ["id", [fields.id.visible && fields.id.required ? ew.Validators.required(fields.id.caption) : null, ew.Validators.integer], fields.id.isInvalid],
            ["department", [fields.department.visible && fields.department.required ? ew.Validators.required(fields.department.caption) : null], fields.department.isInvalid],
            ["description", [fields.description.visible && fields.description.required ? ew.Validators.required(fields.description.caption) : null], fields.description.isInvalid],
            ["actiontobetaken", [fields.actiontobetaken.visible && fields.actiontobetaken.required ? ew.Validators.required(fields.actiontobetaken.caption) : null], fields.actiontobetaken.isInvalid],
            ["Origdate", [fields.Origdate.visible && fields.Origdate.required ? ew.Validators.required(fields.Origdate.caption) : null, ew.Validators.datetime(fields.Origdate.clientFormatPattern)], fields.Origdate.isInvalid],
            ["responsibility", [fields.responsibility.visible && fields.responsibility.required ? ew.Validators.required(fields.responsibility.caption) : null], fields.responsibility.isInvalid],
            ["reviewdate", [fields.reviewdate.visible && fields.reviewdate.required ? ew.Validators.required(fields.reviewdate.caption) : null, ew.Validators.datetime(fields.reviewdate.clientFormatPattern)], fields.reviewdate.isInvalid]
        ])
        <?= Captcha()->getScript() ?>

        // Form_CustomValidate
        .setCustomValidate(
            function (fobj) { // DO NOT CHANGE THIS LINE! (except for adding "async" keyword)!
                    // Your custom validation code here, return false if invalid.
                    return true;
                }
        )

        // Use JavaScript validation or not
        .setValidateRequired(ew.CLIENT_VALIDATE)

        // Dynamic selection lists
        .setLists({
        })
        .build();
    window[form.id] = form;
    currentForm = form;
    loadjs.done(form.id);
});
</script>
<script>
loadjs.ready("head", function () {
    // Write your table-specific client script here, no need to add script tags.
});
</script>
<?php $Page->showPageHeader(); ?>
<?php
$Page->showMessage();
?>
<form name="fmomtransadd" id="fmomtransadd" class="<?= $Page->FormClassName ?>" action="<?= CurrentPageUrl(false) ?>" method="post" novalidate autocomplete="off">
<?php if (Config("CHECK_TOKEN")) { ?>
<input type="hidden" name="<?= $TokenNameKey ?>" value="<?= $TokenName ?>"><!-- CSRF token name -->
<input type="hidden" name="<?= $TokenValueKey ?>" value="<?= $TokenValue ?>"><!-- CSRF token value -->
<?php } ?>
<input type="hidden" name="t" value="momtrans">
<input type="hidden" name="action" id="action" value="insert">
<input type="hidden" name="modal" value="<?= (int)$Page->IsModal ?>">
<?php if (IsJsonResponse()) { ?>
<input type="hidden" name="json" value="1">
<?php } ?>
<input type="hidden" name="<?= $Page->OldKeyName ?>" value="<?= $Page->OldKey ?>">
<div class="ew-add-div"><!-- page* -->
<?php if ($Page->id->Visible) { // id ?>
    <div id="r_id"<?= $Page->id->rowAttributes() ?>>
        <label id="elh_momtrans_id" for="x_id" class="<?= $Page->LeftColumnClass ?>"><?= $Page->id->caption() ?><?= $Page->id->Required ? $Language->phrase("FieldRequiredIndicator") : "" ?></label>
        <div class="<?= $Page->RightColumnClass ?>"><div<?= $Page->id->cellAttributes() ?>>
<span id="el_momtrans_id">
<input type="<?= $Page->id->getInputTextType() ?>" name="x_id" id="x_id" data-table="momtrans" data-field="x_id" value="<?= $Page->id->EditValue ?>" size="30" placeholder="<?= HtmlEncode($Page->id->getPlaceHolder()) ?>" data-format-pattern="<?= HtmlEncode($Page->id->formatPattern()) ?>"<?= $Page->id->editAttributes() ?> aria-describedby="x_id_help">
<?= $Page->id->getCustomMessage() ?>
<div class="invalid-feedback"><?= $Page->id->getErrorMessage() ?></div>
</span>
</div></div>
    </div>
<?php } ?>
<?php if ($Page->department->Visible) { // department ?>
    <div id="r_department"<?= $Page->department->rowAttributes() ?>>
        <label id="elh_momtrans_department" for="x_department" class="<?= $Page->LeftColumnClass ?>"><?= $Page->department->caption() ?><?= $Page->department->Required ? $Language->phrase("FieldRequiredIndicator") : "" ?></label>
        <div class="<?= $Page->RightColumnClass ?>"><div<?= $Page->department->cellAttributes() ?>>
<span id="el_momtrans_department">
<input type="<?= $Page->department->getInputTextType() ?>" name="x_department" id="x_department" data-table="momtrans" data-field="x_department" value="<?= $Page->department->EditValue ?>" size="30" maxlength="65535" placeholder="<?= HtmlEncode($Page->department->getPlaceHolder()) ?>" data-format-pattern="<?= HtmlEncode($Page->department->formatPattern()) ?>"<?= $Page->department->editAttributes() ?> aria-describedby="x_department_help">
<?= $Page->department->getCustomMessage() ?>
<div class="invalid-feedback"><?= $Page->department->getErrorMessage() ?></div>
</span>
</div></div>
    </div>
<?php } ?>
<?php if ($Page->description->Visible) { // description ?>
    <div id="r_description"<?= $Page->description->rowAttributes() ?>>
        <label id="elh_momtrans_description" for="x_description" class="<?= $Page->LeftColumnClass ?>"><?= $Page->description->caption() ?><?= $Page->description->Required ? $Language->phrase("FieldRequiredIndicator") : "" ?></label>
        <div class="<?= $Page->RightColumnClass ?>"><div<?= $Page->description->cellAttributes() ?>>
<span id="el_momtrans_description">
<input type="<?= $Page->description->getInputTextType() ?>" name="x_description" id="x_description" data-table="momtrans" data-field="x_description" value="<?= $Page->description->EditValue ?>" size="30" maxlength="65535" placeholder="<?= HtmlEncode($Page->description->getPlaceHolder()) ?>" data-format-pattern="<?= HtmlEncode($Page->description->formatPattern()) ?>"<?= $Page->description->editAttributes() ?> aria-describedby="x_description_help">
<?= $Page->description->getCustomMessage() ?>
<div class="invalid-feedback"><?= $Page->description->getErrorMessage() ?></div>
</span>
</div></div>
    </div>
<?php } ?>
<?php if ($Page->actiontobetaken->Visible) { // actiontobetaken ?>
    <div id="r_actiontobetaken"<?= $Page->actiontobetaken->rowAttributes() ?>>
        <label id="elh_momtrans_actiontobetaken" for="x_actiontobetaken" class="<?= $Page->LeftColumnClass ?>"><?= $Page->actiontobetaken->caption() ?><?= $Page->actiontobetaken->Required ? $Language->phrase("FieldRequiredIndicator") : "" ?></label>
        <div class="<?= $Page->RightColumnClass ?>"><div<?= $Page->actiontobetaken->cellAttributes() ?>>
<span id="el_momtrans_actiontobetaken">
<input type="<?= $Page->actiontobetaken->getInputTextType() ?>" name="x_actiontobetaken" id="x_actiontobetaken" data-table="momtrans" data-field="x_actiontobetaken" value="<?= $Page->actiontobetaken->EditValue ?>" size="30" maxlength="65535" placeholder="<?= HtmlEncode($Page->actiontobetaken->getPlaceHolder()) ?>" data-format-pattern="<?= HtmlEncode($Page->actiontobetaken->formatPattern()) ?>"<?= $Page->actiontobetaken->editAttributes() ?> aria-describedby="x_actiontobetaken_help">
<?= $Page->actiontobetaken->getCustomMessage() ?>
<div class="invalid-feedback"><?= $Page->actiontobetaken->getErrorMessage() ?></div>
</span>
</div></div>
    </div>
<?php } ?>
<?php if ($Page->Origdate->Visible) { // Origdate ?>
    <div id="r_Origdate"<?= $Page->Origdate->rowAttributes() ?>>
        <label id="elh_momtrans_Origdate" for="x_Origdate" class="<?= $Page->LeftColumnClass ?>"><?= $Page->Origdate->caption() ?><?= $Page->Origdate->Required ? $Language->phrase("FieldRequiredIndicator") : "" ?></label>
        <div class="<?= $Page->RightColumnClass ?>"><div<?= $Page->Origdate->cellAttributes() ?>>
<span id="el_momtrans_Origdate">
<input type="<?= $Page->Origdate->getInputTextType() ?>" name="x_Origdate" id="x_Origdate" data-table="momtrans" data-field="x_Origdate" value="<?= $Page->Origdate->EditValue ?>" placeholder="<?= HtmlEncode($Page->Origdate->getPlaceHolder()) ?>" data-format-pattern="<?= HtmlEncode($Page->Origdate->formatPattern()) ?>"<?= $Page->Origdate->editAttributes() ?> aria-describedby="x_Origdate_help">
<?= $Page->Origdate->getCustomMessage() ?>
<div class="invalid-feedback"><?= $Page->Origdate->getErrorMessage() ?></div>
<?php if (!$Page->Origdate->ReadOnly && !$Page->Origdate->Disabled && !isset($Page->Origdate->EditAttrs["readonly"]) && !isset($Page->Origdate->EditAttrs["disabled"])) { ?>
<script>
loadjs.ready(["fmomtransadd", "datetimepicker"], function () {
    let format = "<?= DateFormat(0) ?>",
        options = {
            localization: {
                locale: ew.LANGUAGE_ID + "-u-nu-" + ew.getNumberingSystem(),
                hourCycle: format.match(/H/) ? "h24" : "h12",
                format,
                ...ew.language.phrase("datetimepicker")
            },
            display: {
                icons: {
                    previous: ew.IS_RTL ? "fa-solid fa-chevron-right" : "fa-solid fa-chevron-left",
                    next: ew.IS_RTL ? "fa-solid fa-chevron-left" : "fa-solid fa-chevron-right"
                },
                components: {
                    hours: !!format.match(/h/i),
                    minutes: !!format.match(/m/),
                    seconds: !!format.match(/s/i)
                },
                theme: ew.getPreferredTheme()
            }
        };
    ew.createDateTimePicker("fmomtransadd", "x_Origdate", ew.deepAssign({"useCurrent":false,"display":{"sideBySide":false}}, options));
});
</script>
<?php } ?>
</span>
</div></div>
    </div>
<?php } ?>
<?php if ($Page->responsibility->Visible) { // responsibility ?>
    <div id="r_responsibility"<?= $Page->responsibility->rowAttributes() ?>>
        <label id="elh_momtrans_responsibility" for="x_responsibility" class="<?= $Page->LeftColumnClass ?>"><?= $Page->responsibility->caption() ?><?= $Page->responsibility->Required ? $Language->phrase("FieldRequiredIndicator") : "" ?></label>
        <div class="<?= $Page->RightColumnClass ?>"><div<?= $Page->responsibility->cellAttributes() ?>>
<span id="el_momtrans_responsibility">
<input type="<?= $Page->responsibility->getInputTextType() ?>" name="x_responsibility" id="x_responsibility" data-table="momtrans" data-field="x_responsibility" value="<?= $Page->responsibility->EditValue ?>" size="30" maxlength="65535" placeholder="<?= HtmlEncode($Page->responsibility->getPlaceHolder()) ?>" data-format-pattern="<?= HtmlEncode($Page->responsibility->formatPattern()) ?>"<?= $Page->responsibility->editAttributes() ?> aria-describedby="x_responsibility_help">
<?= $Page->responsibility->getCustomMessage() ?>
<div class="invalid-feedback"><?= $Page->responsibility->getErrorMessage() ?></div>
</span>
</div></div>
    </div>
<?php } ?>
<?php if ($Page->reviewdate->Visible) { // reviewdate ?>
    <div id="r_reviewdate"<?= $Page->reviewdate->rowAttributes() ?>>
        <label id="elh_momtrans_reviewdate" for="x_reviewdate" class="<?= $Page->LeftColumnClass ?>"><?= $Page->reviewdate->caption() ?><?= $Page->reviewdate->Required ? $Language->phrase("FieldRequiredIndicator") : "" ?></label>
        <div class="<?= $Page->RightColumnClass ?>"><div<?= $Page->reviewdate->cellAttributes() ?>>
<span id="el_momtrans_reviewdate">
<input type="<?= $Page->reviewdate->getInputTextType() ?>" name="x_reviewdate" id="x_reviewdate" data-table="momtrans" data-field="x_reviewdate" value="<?= $Page->reviewdate->EditValue ?>" placeholder="<?= HtmlEncode($Page->reviewdate->getPlaceHolder()) ?>" data-format-pattern="<?= HtmlEncode($Page->reviewdate->formatPattern()) ?>"<?= $Page->reviewdate->editAttributes() ?> aria-describedby="x_reviewdate_help">
<?= $Page->reviewdate->getCustomMessage() ?>
<div class="invalid-feedback"><?= $Page->reviewdate->getErrorMessage() ?></div>
<?php if (!$Page->reviewdate->ReadOnly && !$Page->reviewdate->Disabled && !isset($Page->reviewdate->EditAttrs["readonly"]) && !isset($Page->reviewdate->EditAttrs["disabled"])) { ?>
<script>
loadjs.ready(["fmomtransadd", "datetimepicker"], function () {
    let format = "<?= DateFormat(0) ?>",
        options = {
            localization: {
                locale: ew.LANGUAGE_ID + "-u-nu-" + ew.getNumberingSystem(),
                hourCycle: format.match(/H/) ? "h24" : "h12",
                format,
                ...ew.language.phrase("datetimepicker")
            },
            display: {
                icons: {
                    previous: ew.IS_RTL ? "fa-solid fa-chevron-right" : "fa-solid fa-chevron-left",
                    next: ew.IS_RTL ? "fa-solid fa-chevron-left" : "fa-solid fa-chevron-right"
                },
                components: {
                    hours: !!format.match(/h/i),
                    minutes: !!format.match(/m/),
                    seconds: !!format.match(/s/i)
                },
                theme: ew.getPreferredTheme()
            }
        };
    ew.createDateTimePicker("fmomtransadd", "x_reviewdate", ew.deepAssign({"useCurrent":false,"display":{"sideBySide":false}}, options));
});
</script>
<?php } ?>
</span>
</div></div>
    </div>
<?php } ?>
</div><!-- /page* -->
<?= $Page->IsModal ? '<template class="ew-modal-buttons">' : '<div class="row ew-buttons">' ?><!-- buttons .row -->
    <div class="<?= $Page->OffsetColumnClass ?>"><!-- buttons offset -->
<button class="btn btn-primary ew-btn" name="btn-action" id="btn-action" type="submit" form="fmomtransadd"><?= $Language->phrase("AddBtn") ?></button>
<?php if (IsJsonResponse()) { ?>
<button class="btn btn-default ew-btn" name="btn-cancel" id="btn-cancel" type="button" data-bs-dismiss="modal"><?= $Language->phrase("CancelBtn") ?></button>
<?php } else { ?>
<button class="btn btn-default ew-btn" name="btn-cancel" id="btn-cancel" type="button" form="fmomtransadd" data-href="<?= HtmlEncode(GetUrl($Page->getReturnUrl())) ?>"><?= $Language->phrase("CancelBtn") ?></button>
<?php } ?>
    </div><!-- /buttons offset -->
<?= $Page->IsModal ? "</template>" : "</div>" ?><!-- /buttons .row -->
</form>
<?php
$Page->showPageFooter();
echo GetDebugMessage();
?>
<script>
// Field event handlers
loadjs.ready("head", function() {
    ew.addEventHandlers("momtrans");
});
</script>
<script>
loadjs.ready("load", function () {
    // Write your table-specific startup script here, no need to add script tags.
});
</script>
